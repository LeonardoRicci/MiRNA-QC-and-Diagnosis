library(testthat)
library(MiRNAQCD)

test_check("MiRNAQCD")
